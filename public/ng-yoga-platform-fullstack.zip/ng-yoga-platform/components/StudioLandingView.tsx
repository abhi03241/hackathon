'use client';

import React, {useState} from 'react';
import {
  ArrowRight,
  MapPin,
  Clock,
  ShieldCheck,
  ExternalLink,
  Phone,
  HeartPulse,
  FolderArchive,
  Compass,
  CheckCircle2,
} from 'lucide-react';
import type {Batch, Programme, ProgrammeType} from '@/types';
import {STUDIO_WHATSAPP_NUMBER} from '@/lib/whatsapp';

interface StudioLandingViewProps {
  programmes: Programme[];
  batches: Batch[];
  onStartHealthIntake: () => void;
  onExploreBatches: (programme?: ProgrammeType) => void;
  onOpenAuthModal: () => void;
  onDownloadPlatformZip: () => void;
}

const MINDFUL_SEQUENCE = [
  {
    step: '01 · Structural Grounding',
    sanskrit: 'Utthita Parsvakonasana',
    english: 'Extended Side Angle',
    cue: 'Ground the outer heel and lengthen through the lateral ribcage. Front knee stacks cleanly over the ankle without medial collapse.',
  },
  {
    step: '02 · Core Stabilization',
    sanskrit: 'Chaturanga Dandasana',
    english: 'Four-Limbed Staff Transition',
    cue: 'Transition with slow eccentric control. Elbows hug the ribs while broad scapulae protect the anterior shoulder capsule.',
  },
  {
    step: '03 · Thoracic Expansion',
    sanskrit: 'Urdhva Mukha Svanasana',
    english: 'Upward-Facing Dog',
    cue: 'Open the sternum and anterior spine while lifting the thighs clear of the mat, keeping the lumbar vertebrae decompressed.',
  },
  {
    step: '04 · Autonomic Stillness',
    sanskrit: 'Vajrasana Anjali Mudra',
    english: 'Centered Breath Integration',
    cue: 'Complete the sequence in quiet stillness. Allow heart rate variability to settle before stepping off the mat.',
  },
];

const COMMUNITY_REVIEWS = [
  {
    tag: 'Lumbar Traction · Wall Rope Yoga Therapy',
    quote:
      'Long desk hours had left my lower back constantly stiff. Within three weeks of guided wall-rope spinal decompression here at Prem Plaza, my mornings feel completely pain-free.',
    author: 'Prateek D. · Ashok Nagar, Indore (8:30 AM Cohort)',
  },
  {
    tag: 'Metabolic Stamina · Sunrise Vinyasa Flow',
    quote:
      'The 6:30 AM cohort sets the rhythm for my entire day. It builds genuine metabolic endurance without ever rushing transitions or straining the knees.',
    author: 'Roshni K. · Sapna Sangeeta, Indore (6:30 AM Cohort)',
  },
  {
    tag: 'Clinical Precision · Evening Hatha & Props',
    quote:
      'What sets NG Yoga Studio apart from generic fitness apps is tactile posture correction. Every block, belt, and wall-rope setup is tailored to your spine.',
    author: 'Anjali V. · Bhawarkuan, Indore (7:00 PM Cohort)',
  },
];

export default function StudioLandingView({
  programmes,
  batches,
  onStartHealthIntake,
  onExploreBatches,
  onOpenAuthModal,
  onDownloadPlatformZip,
}: StudioLandingViewProps) {
  const [selectedStreamIdx, setSelectedStreamIdx] = useState(0);
  const activeProg = programmes[selectedStreamIdx] || programmes[0];

  return (
    <div className="space-y-14">
      {/* 01 · BOTANICAL SANCTUARY HERO SPLIT */}
      <section className="rounded-xl border border-[#CBD8CE] bg-white p-6 sm:p-10 lg:p-12 shadow-sm">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="font-mono text-xs uppercase tracking-[0.16em] text-[#4E675E]">
                ASHOK NAGAR, INDORE · CLINICAL SOMATIC &amp; WALL-ROPE SANCTUARY
              </div>

              <h1 className="font-display text-4xl sm:text-5xl lg:text-[54px] font-semibold tracking-tight text-[#0F241D] leading-[1.08]">
                Precision alignment guided by clinical safety, not algorithms.
              </h1>

              <p className="text-base sm:text-lg text-[#4E675E] leading-relaxed max-w-2xl">
                At NG Yoga Studio (Prem Plaza, Ashok Nagar), every new
                practitioner completes a deterministic health screening before
                booking. Whether you need lumbar wall-rope traction, PCOD
                endocrine recovery, or metabolic Vinyasa, our routing engine
                guarantees safe cohort placement.
              </p>
            </div>

            <div className="space-y-4 pt-2">
              <div className="flex flex-wrap items-center gap-3.5">
                <button
                  type="button"
                  onClick={onStartHealthIntake}
                  className="px-6 py-3.5 rounded-lg bg-[#1B4332] text-[#F4F7F4] hover:bg-[#0F241D] font-medium text-sm transition-colors flex items-center gap-2.5 cursor-pointer"
                >
                  <span>Begin Clinical Health Intake (₹0 Trial)</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => onExploreBatches()}
                  className="px-5 py-3.5 rounded-lg border border-[#CBD8CE] bg-[#E6EFE9]/60 text-[#0F241D] hover:bg-[#E6EFE9] font-medium text-sm transition-colors cursor-pointer"
                >
                  Inspect Live Cohort Schedule
                </button>
              </div>

              <div className="text-xs text-[#4E675E] font-mono">
                Rule R1–R6 Safety Guarded · 1 Complimentary Trial per Phone
                (Rule B2) · Capacity-Locked Batches (Rule B1)
              </div>
            </div>
          </div>

          {/* Right Column: Deep Cypress Clinical Spotlight Card */}
          <div className="lg:col-span-5 rounded-xl bg-[#1B4332] text-[#F4F7F4] p-6 sm:p-8 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between font-mono text-xs text-[#A3B8AF] border-b border-white/15 pb-3">
                <span>CLINICAL COHORT SPOTLIGHT</span>
                <span className="text-[#86EFAC]">RULE R2 SAFEGUARD</span>
              </div>

              <h2 className="font-display text-2xl sm:text-3xl font-semibold text-white leading-snug">
                Iyengar Wall-Rope Spine &amp; Knee Therapy
              </h2>

              <p className="text-xs sm:text-sm text-[#E6EFE9]/85 leading-relaxed">
                Supervised personally by Founder <strong>NG Gothane</strong>.
                Practitioners reporting back pain, knee stiffness, or high blood
                pressure are automatically protected from high-impact Power and
                Advanced flows and routed to prop-assisted therapeutic cohorts.
              </p>

              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-white/15 font-mono text-xs">
                <div className="p-3 rounded-lg bg-white/5">
                  <div className="text-[10px] text-[#A3B8AF] uppercase">
                    DAILY SESSIONS
                  </div>
                  <div className="font-semibold text-white mt-0.5 tabular-nums">
                    08:30 AM · 05:00 PM
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-white/5">
                  <div className="text-[10px] text-[#A3B8AF] uppercase">
                    MICRO-COHORT CAP
                  </div>
                  <div className="font-semibold text-white mt-0.5 tabular-nums">
                    6 – 8 Practitioners
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-white/5">
                  <div className="text-[10px] text-[#A3B8AF] uppercase">
                    THERAPY PROPS
                  </div>
                  <div className="font-semibold text-white mt-0.5">
                    Wall Ropes · Bolsters
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-white/5">
                  <div className="text-[10px] text-[#A3B8AF] uppercase">
                    FIRST VISIT PASS
                  </div>
                  <div className="font-semibold text-[#86EFAC] mt-0.5">
                    ₹0 Complimentary
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-white/15 space-y-3">
              <button
                type="button"
                onClick={onStartHealthIntake}
                className="w-full py-3 px-4 rounded-lg bg-[#C86446] text-white hover:bg-[#b55538] font-medium text-xs uppercase tracking-wider transition-colors cursor-pointer"
              >
                Run 30-Second Programme Matcher →
              </button>

              <div className="flex items-center justify-between text-[11px] font-mono text-[#E6EFE9]/80">
                <button
                  type="button"
                  onClick={onOpenAuthModal}
                  className="underline hover:text-white cursor-pointer"
                >
                  Staff / Owner JWT Login
                </button>
                <button
                  type="button"
                  onClick={onDownloadPlatformZip}
                  className="underline hover:text-white flex items-center gap-1 cursor-pointer"
                >
                  <FolderArchive className="w-3.5 h-3.5" />
                  <span>Download FastAPI + Next.js ZIP</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 02 · INTERACTIVE CLINICAL PROGRAMME ARCHITECTURE */}
      <section className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#CBD8CE] pb-4">
          <div>
            <div className="font-mono text-xs uppercase tracking-[0.16em] text-[#4E675E]">
              02 · SEVEN SPECIALIZED STUDIO PROGRAMMES
            </div>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#0F241D] mt-1">
              Curated cohorts for therapeutic &amp; athletic progression
            </h2>
          </div>
          <span className="text-xs font-mono text-[#4E675E]">
            Select any stream to inspect anatomical focus &amp; live seat counts
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Selector Tabs (5 cols) */}
          <div className="lg:col-span-5 space-y-2">
            {programmes.map((prog, idx) => {
              const active = idx === selectedStreamIdx;
              return (
                <button
                  key={prog.id}
                  type="button"
                  onClick={() => setSelectedStreamIdx(idx)}
                  className={`w-full text-left p-4 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                    active
                      ? 'border-[#1B4332] bg-[#1B4332] text-[#F4F7F4] shadow-sm'
                      : 'border-[#CBD8CE] bg-white text-[#0F241D] hover:bg-[#E6EFE9]/50'
                  }`}
                >
                  <div>
                    <div
                      className={`font-mono text-[11px] ${
                        active ? 'text-[#A3B8AF]' : 'text-[#4E675E]'
                      }`}
                    >
                      0{idx + 1} · {prog.type}
                    </div>
                    <div className="font-display text-lg font-semibold mt-0.5">
                      {prog.name}
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 shrink-0" />
                </button>
              );
            })}
          </div>

          {/* Right Programme Inspector Card (7 cols) */}
          {activeProg && (
            <div className="lg:col-span-7 rounded-xl border border-[#CBD8CE] bg-white p-6 sm:p-8 space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#CBD8CE] pb-4 font-mono text-xs text-[#4E675E]">
                <span>
                  PROGRAMME 0{selectedStreamIdx + 1} / 0{programmes.length} ·{' '}
                  {activeProg.type}
                </span>
                <span>INSTRUCTOR: {activeProg.instructor}</span>
              </div>

              <div>
                <h3 className="font-display text-3xl font-semibold text-[#0F241D]">
                  {activeProg.name}
                </h3>
                <p className="text-sm sm:text-base text-[#4E675E] mt-2 leading-relaxed">
                  {activeProg.description}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-[#E6EFE9]/55 border border-[#CBD8CE]">
                  <div className="font-mono text-[10px] uppercase tracking-wider text-[#4E675E]">
                    CLINICAL &amp; SOMATIC FOCUS
                  </div>
                  <div className="text-xs font-semibold text-[#0F241D] mt-1">
                    {activeProg.focusAreas}
                  </div>
                </div>
                <div className="p-4 rounded-lg bg-[#E6EFE9]/55 border border-[#CBD8CE]">
                  <div className="font-mono text-[10px] uppercase tracking-wider text-[#4E675E]">
                    STUDIO PROPS PROVIDED
                  </div>
                  <div className="text-xs font-semibold text-[#0F241D] mt-1">
                    {activeProg.propsUsed}
                  </div>
                </div>
              </div>

              <div className="space-y-2.5">
                <div className="font-mono text-xs uppercase tracking-wider text-[#4E675E]">
                  LIVE SCHEDULED BATCHES FOR {activeProg.type.toUpperCase()}:
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {batches
                    .filter((b) => b.programme_type === activeProg.type)
                    .map((b) => {
                      const left = Math.max(0, b.capacity - b.booked_count);
                      return (
                        <div
                          key={b.id}
                          className="p-3.5 rounded-lg border border-[#CBD8CE] bg-[#F4F7F4] flex items-center justify-between text-xs font-mono"
                        >
                          <div>
                            <div className="font-semibold text-[#0F241D]">
                              {b.timing_label}
                            </div>
                            <div className="text-[11px] text-[#4E675E]">
                              {b.time_slot.toUpperCase()} · {b.batch_date}
                            </div>
                          </div>
                          <span
                            className={`font-semibold tabular-nums ${
                              left === 0 ? 'text-[#B91C1C]' : 'text-[#15803D]'
                            }`}
                          >
                            {left === 0
                              ? 'FULL (Waitlist)'
                              : `${left}/${b.capacity} mats`}
                          </span>
                        </div>
                      );
                    })}
                </div>
              </div>

              <div className="pt-4 border-t border-[#CBD8CE] flex flex-wrap items-center justify-between gap-4">
                <button
                  type="button"
                  onClick={() => onExploreBatches(activeProg.type)}
                  className="px-5 py-2.5 rounded-lg bg-[#1B4332] text-white hover:bg-[#0F241D] text-xs font-medium cursor-pointer"
                >
                  Reserve Mat in {activeProg.type} →
                </button>
                <button
                  type="button"
                  onClick={onStartHealthIntake}
                  className="text-xs font-mono text-[#1B4332] underline hover:no-underline cursor-pointer"
                >
                  Check Health Routing Rules (R1–R6)
                </button>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* 03 · BIOMECHANICAL SEQUENCE & FOUNDER CREDENTIALS */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 rounded-xl border border-[#CBD8CE] bg-white p-6 sm:p-8 space-y-5">
          <div className="font-mono text-xs uppercase tracking-[0.16em] text-[#4E675E]">
            03 · BIOMECHANICAL BREATH-TO-POSTURE SEQUENCE
          </div>
          <h3 className="font-display text-3xl font-semibold text-[#0F241D]">
            Four-stage studio alignment progression
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            {MINDFUL_SEQUENCE.map((seq) => (
              <div
                key={seq.sanskrit}
                className="p-4 rounded-lg border border-[#CBD8CE] bg-[#F4F7F4] space-y-1.5"
              >
                <div className="font-mono text-[11px] text-[#4E675E]">
                  {seq.step}
                </div>
                <div className="font-display text-xl font-semibold text-[#0F241D]">
                  {seq.sanskrit}
                </div>
                <div className="font-mono text-xs text-[#1B4332]">
                  {seq.english}
                </div>
                <p className="text-xs text-[#4E675E] leading-relaxed pt-1">
                  {seq.cue}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5 rounded-xl bg-[#0F241D] text-[#F4F7F4] p-6 sm:p-8 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="font-mono text-xs uppercase tracking-[0.18em] text-[#86EFAC]">
              04 · CLINICAL LEADERSHIP · ASHOK NAGAR, INDORE
            </div>
            <h3 className="font-display text-3xl font-semibold text-white leading-snug">
              “Yoga is not about becoming someone else. It is about returning to
              your structural center.”
            </h3>
            <p className="text-xs sm:text-sm text-[#E6EFE9]/80 leading-relaxed">
              Generic ₹299 mobile apps cannot observe lumbar disc shear, knee
              valgus, or blood-pressure spikes. At Prem Plaza, every cohort is
              personally supervised with tactile adjustments and certified
              Iyengar wall ropes.
            </p>
          </div>

          <div className="pt-4 border-t border-white/15 space-y-2 text-xs">
            <div className="font-display text-2xl font-semibold text-white">
              Narayan Gothane (NG Gothane)
            </div>
            <div className="font-mono text-[11px] text-[#A3B8AF]">
              FOUNDER &amp; HEAD THERAPY INSTRUCTOR · NG YOGA STUDIO INDORE
            </div>
            <div className="text-xs text-[#E6EFE9]/90 pt-1">
              Specialties: Iyengar Wall-Rope Spinal Traction • Structural
              Backbends • Metabolic Vinyasa • PCOD Endocrine Recovery
            </div>
          </div>
        </div>
      </section>

      {/* 04 · PRACTITIONER OUTCOMES & PREM PLAZA STUDIO CARD */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 space-y-4">
          <div className="font-mono text-xs uppercase tracking-[0.16em] text-[#4E675E]">
            05 · INDORE PRACTITIONER OUTCOMES
          </div>
          <div className="grid grid-cols-1 gap-4">
            {COMMUNITY_REVIEWS.map((rev) => (
              <div
                key={rev.author}
                className="rounded-xl border border-[#CBD8CE] bg-white p-5 space-y-2"
              >
                <div className="font-mono text-[11px] uppercase tracking-wider text-[#1B4332]">
                  {rev.tag}
                </div>
                <p className="text-sm text-[#0F241D] leading-relaxed italic">
                  “{rev.quote}”
                </p>
                <div className="font-mono text-xs font-semibold text-[#4E675E] pt-1">
                  — {rev.author}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5 rounded-xl border border-[#CBD8CE] bg-[#E6EFE9] p-6 sm:p-8 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="font-mono text-xs uppercase tracking-[0.16em] text-[#4E675E]">
              VERIFIED STUDIO LOCATION · INDORE (452001)
            </div>
            <h3 className="font-display text-3xl font-semibold text-[#0F241D]">
              Prem Plaza, Near ICICI Bank, Ashok Nagar
            </h3>

            <div className="space-y-3 text-xs text-[#0F241D]/90 pt-2">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 shrink-0 mt-0.5 text-[#1B4332]" />
                <span>
                  Prem Plaza, 5 &amp; 6, Samrat, Near ICICI Bank, Ashok Nagar,
                  Indore, Madhya Pradesh 452001
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 shrink-0 mt-0.5 text-[#1B4332]" />
                <span>
                  Monday – Saturday: 6:30 AM – 10:00 AM &amp; 5:00 PM – 9:00 PM
                  <br />
                  Sunday Partner &amp; Restorative: 7:00 AM – 9:00 AM
                </span>
              </div>
              <div className="flex items-center gap-2.5 font-mono">
                <Phone className="w-4 h-4 shrink-0 text-[#1B4332]" />
                <span>+91 91717 44543 / +91 70006 56390</span>
              </div>
            </div>
          </div>

          <div className="space-y-2.5 pt-4 border-t border-[#CBD8CE]">
            <a
              href={`https://wa.me/${STUDIO_WHATSAPP_NUMBER}?text=${encodeURIComponent(
                'Namaste NG Yoga Studio Indore! I would like to book a Free Trial Session at Prem Plaza, Ashok Nagar.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 px-4 rounded-lg bg-[#1B4332] text-white hover:bg-[#0F241D] font-mono text-xs uppercase tracking-wider font-semibold flex items-center justify-center gap-2"
            >
              <span>Connect with Prem Plaza Desk on WhatsApp</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <div className="text-[11px] font-mono text-[#4E675E] text-center">
              This is not medical advice. Consult a qualified doctor for medical
              concerns.
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
