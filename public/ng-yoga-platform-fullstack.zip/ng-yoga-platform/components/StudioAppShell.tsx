'use client';

import React, {useEffect, useState, useCallback} from 'react';
import {
  Search,
  Download,
  RotateCcw,
  X,
  FileSpreadsheet,
  ArrowUpRight,
  Lock,
  FolderArchive,
} from 'lucide-react';
import type {
  Batch,
  Booking,
  Checkin,
  Condition,
  ConversionStats,
  Goal,
  HealthProfile,
  Member,
  Membership,
  Programme,
  ProgrammeType,
  RetentionRiskItem,
  RoutingResult,
  WaitlistEntry,
} from '@/types';
import {routeMember} from '@/lib/routing';
import StudioLandingView from '@/components/StudioLandingView';
import OnboardingRoutingView from '@/components/OnboardingRoutingView';
import BatchesPlansView from '@/components/BatchesPlansView';
import StaffCheckinView from '@/components/StaffCheckinView';
import OwnerRetentionDashboard from '@/components/OwnerRetentionDashboard';
import AuthPortalModal, {
  type AuthenticatedUser,
} from '@/components/AuthPortalModal';

interface StudioSnapshot {
  programmes: Programme[];
  members: Member[];
  health_profiles: HealthProfile[];
  batches: Batch[];
  memberships: Membership[];
  bookings: Booking[];
  checkins: Checkin[];
  waitlist: WaitlistEntry[];
  retention_triage: RetentionRiskItem[];
  conversion_stats: ConversionStats;
}

export type ActiveTab = 'landing' | 'intake' | 'batches' | 'checkin' | 'owner';

export default function StudioAppShell({
  initialTab = 'landing',
}: {
  initialTab?: ActiveTab;
}) {
  const [snapshot, setSnapshot] = useState<StudioSnapshot | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveTab>(initialTab);
  const [programmeFilter, setProgrammeFilter] = useState<
    ProgrammeType | 'ALL'
  >('ALL');

  const [currentUser, setCurrentUser] = useState<AuthenticatedUser | null>({
    id: 'usr-owner-ng',
    email: 'owner@ngyoga.in',
    name: 'Narayan Gothane (Studio Owner)',
    role: 'owner',
    phone: '9171744543',
    tenant_id: 'tenant-indore-ashok-nagar',
  });
  const [, setJwtToken] = useState<string>('demo-owner-jwt');
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);

  const [activeMember, setActiveMember] = useState<Member | null>(null);
  const [activeRouting, setActiveRouting] = useState<RoutingResult | null>(
    null
  );
  const [activeConditions, setActiveConditions] = useState<Condition[]>([
    'high_bp',
    'back_pain',
  ]);
  const [activeGoal, setActiveGoal] = useState<Goal>('fitness');
  const [activeMembership, setActiveMembership] =
    useState<Membership | null>(null);
  const [hasUsedTrial, setHasUsedTrial] = useState<boolean>(false);

  const [cmdOpen, setCmdOpen] = useState<boolean>(false);
  const [cmdQuery, setCmdQuery] = useState<string>('');
  const [resetting, setResetting] = useState<boolean>(false);

  const syncActiveMemberFromSnapshot = useCallback(
    (snap: StudioSnapshot, targetPhone?: string) => {
      const phoneToFind = targetPhone || activeMember?.phone || '9826033333';
      const foundMember =
        snap.members.find((m) => m.phone === phoneToFind) || snap.members[0];
      if (!foundMember) return;

      const hp = snap.health_profiles.find(
        (h) => h.member_id === foundMember.id
      );
      const conds: Condition[] = hp?.conditions || ['none'];
      const goal: Goal = hp?.main_goal || 'fitness';
      const routing = routeMember({
        conditions: conds,
        goal,
        experienceLevel: foundMember.experience_level,
      });

      const latestMs =
        snap.memberships
          .filter((ms) => ms.member_id === foundMember.id)
          .sort((a, b) => b.expiry_date.localeCompare(a.expiry_date))[0] ||
        null;

      const trialUsed = snap.bookings.some(
        (b) =>
          (b.member_id === foundMember.id ||
            b.member_phone === foundMember.phone) &&
          b.booking_type === 'trial' &&
          b.status !== 'cancelled'
      );

      setActiveMember(foundMember);
      setActiveConditions(conds);
      setActiveGoal(goal);
      setActiveRouting(routing);
      setActiveMembership(latestMs);
      setHasUsedTrial(trialUsed);
    },
    [activeMember?.phone]
  );

  useEffect(() => {
    fetch('/api/studio')
      .then((res) => res.json())
      .then((data: StudioSnapshot) => {
        setSnapshot(data);
        syncActiveMemberFromSnapshot(data, '9826033333');
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCmdOpen((prev) => !prev);
      }
      if (e.key === 'Escape') {
        setCmdOpen(false);
        setAuthModalOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const handleSnapshotUpdate = (newSnap: unknown) => {
    const typed = newSnap as StudioSnapshot;
    setSnapshot(typed);
    syncActiveMemberFromSnapshot(typed, activeMember?.phone);
  };

  const handleResetDemoData = async () => {
    setResetting(true);
    try {
      const res = await fetch('/api/studio', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({action: 'reset'}),
      });
      const data = await res.json();
      if (data.snapshot) {
        setSnapshot(data.snapshot);
        syncActiveMemberFromSnapshot(data.snapshot, '9826033333');
      }
      setCmdOpen(false);
    } finally {
      setResetting(false);
    }
  };

  const handleDownloadPlatformZip = () => {
    const a = document.createElement('a');
    a.href = '/ng-yoga-platform-fullstack.zip';
    a.download = 'ng-yoga-platform-fullstack.zip';
    a.click();
  };

  const handleExportJson = () => {
    if (!snapshot) return;
    const blob = new Blob([JSON.stringify(snapshot, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ng-yoga-studio-indore-${
      new Date().toISOString().split('T')[0]
    }.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportRetentionCsv = () => {
    if (!snapshot) return;
    const headers = [
      'Priority',
      'Risk_Category',
      'Name',
      'Phone',
      'Recommended_Programme',
      'Plan',
      'Expiry_Date',
      'Days_Inactive',
      'WhatsApp_Link',
    ];
    const rows = snapshot.retention_triage.map((r) => [
      `P${r.triage_priority}`,
      r.risk_category,
      `"${r.name}"`,
      r.phone,
      `"${r.recommended_programme}"`,
      `"${r.plan_label || 'Trial Only'}"`,
      r.expiry_date || 'N/A',
      String(r.days_inactive),
      `"${r.whatsapp_url}"`,
    ]);
    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], {type: 'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ng-yoga-retention-triage-${
      new Date().toISOString().split('T')[0]
    }.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!snapshot) {
    return (
      <div className="min-h-screen bg-[#F4F7F4] text-[#0F241D] flex items-center justify-center p-6">
        <div className="rounded-xl border border-[#CBD8CE] bg-white p-8 max-w-md w-full text-center space-y-3 shadow-sm">
          <div className="font-mono text-xs uppercase tracking-[0.2em] text-[#4E675E]">
            NG YOGA STUDIO · PREM PLAZA, ASHOK NAGAR
          </div>
          <div className="font-display text-2xl font-semibold">
            Loading Clinical Somatic Platform...
          </div>
        </div>
      </div>
    );
  }

  const filteredCmdMembers = snapshot.members.filter(
    (m) =>
      m.name.toLowerCase().includes(cmdQuery.toLowerCase()) ||
      m.phone.includes(cmdQuery)
  );

  const canAccessStaff =
    currentUser?.role === 'staff' || currentUser?.role === 'owner';
  const canAccessOwner = currentUser?.role === 'owner';

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F7F4] text-[#0F241D]">
      {/* Strict 3-Zone Top Bar Contract (Zone 1: Wordmark | Zone 2: 5 Nav Links | Zone 3: 1 Primary CTA) */}
      <header className="sticky top-0 z-40 bg-[#F4F7F4]/95 backdrop-blur border-b border-[#CBD8CE]">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-8 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single text element wordmark */}
          <button
            type="button"
            onClick={() => setActiveTab('landing')}
            className="font-display text-xl sm:text-2xl font-bold tracking-tight text-[#0F241D] whitespace-nowrap shrink-0 cursor-pointer"
          >
            NG Yoga Studio
          </button>

          {/* Zone 2: 5 concise single-line navigation links */}
          <nav className="flex items-center gap-4 sm:gap-6 overflow-x-auto text-xs sm:text-sm font-medium text-[#0F241D]">
            <button
              type="button"
              onClick={() => setActiveTab('landing')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'landing'
                  ? 'border-b-2 border-[#1B4332] text-[#1B4332] font-semibold'
                  : 'text-[#4E675E] hover:text-[#0F241D]'
              }`}
            >
              Studio Home
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('intake')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'intake'
                  ? 'border-b-2 border-[#1B4332] text-[#1B4332] font-semibold'
                  : 'text-[#4E675E] hover:text-[#0F241D]'
              }`}
            >
              Health Intake
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('batches')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'batches'
                  ? 'border-b-2 border-[#1B4332] text-[#1B4332] font-semibold'
                  : 'text-[#4E675E] hover:text-[#0F241D]'
              }`}
            >
              Batches &amp; Plans
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('checkin')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'checkin'
                  ? 'border-b-2 border-[#1B4332] text-[#1B4332] font-semibold'
                  : 'text-[#4E675E] hover:text-[#0F241D]'
              }`}
            >
              Staff Check-In
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('owner')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'owner'
                  ? 'border-b-2 border-[#1B4332] text-[#1B4332] font-semibold'
                  : 'text-[#4E675E] hover:text-[#0F241D]'
              }`}
            >
              Owner Retention
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action Button */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => setAuthModalOpen(true)}
              className="px-4 py-2 rounded-lg bg-[#1B4332] text-[#F4F7F4] hover:bg-[#0F241D] font-mono text-xs uppercase tracking-wider font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {currentUser
                ? `${currentUser.role.toUpperCase()} Portal`
                : 'Sign In'}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Canvas */}
      <main className="flex-1 max-w-[1360px] w-full mx-auto px-4 sm:px-8 py-8">
        {activeTab === 'landing' && (
          <StudioLandingView
            programmes={snapshot.programmes}
            batches={snapshot.batches}
            onStartHealthIntake={() => setActiveTab('intake')}
            onExploreBatches={(prog) => {
              setProgrammeFilter(prog || 'ALL');
              setActiveTab('batches');
            }}
            onOpenAuthModal={() => setAuthModalOpen(true)}
            onDownloadPlatformZip={handleDownloadPlatformZip}
          />
        )}

        {activeTab === 'intake' && (
          <OnboardingRoutingView
            programmes={snapshot.programmes}
            activeMember={activeMember}
            activeRouting={activeRouting}
            activeConditions={activeConditions}
            activeGoal={activeGoal}
            activeMembership={activeMembership}
            hasUsedTrial={hasUsedTrial}
            onIntakeSuccess={(payload) => {
              setActiveMember(payload.member);
              setActiveRouting(payload.routing);
              setActiveConditions(payload.conditions);
              setActiveGoal(payload.goal);
              setActiveMembership(payload.active_membership);
              setHasUsedTrial(payload.has_used_trial);
              setSnapshot(payload.snapshot as StudioSnapshot);
            }}
            onNavigateToBatches={(prog) => {
              setProgrammeFilter(prog || 'ALL');
              setActiveTab('batches');
            }}
            onNavigateToMemberships={() => {
              setProgrammeFilter('ALL');
              setActiveTab('batches');
              setTimeout(() => {
                document
                  .getElementById('membership-plans')
                  ?.scrollIntoView({behavior: 'smooth'});
              }, 100);
            }}
          />
        )}

        {activeTab === 'batches' && (
          <BatchesPlansView
            batches={snapshot.batches}
            bookings={snapshot.bookings}
            waitlist={snapshot.waitlist}
            members={snapshot.members}
            activeMember={activeMember}
            activeRouting={activeRouting}
            activeMembership={activeMembership}
            hasUsedTrial={hasUsedTrial}
            initialProgrammeFilter={programmeFilter}
            onSelectActiveMemberByPhone={(phone) =>
              syncActiveMemberFromSnapshot(snapshot, phone)
            }
            onSnapshotUpdate={handleSnapshotUpdate}
            onNavigateToIntake={() => setActiveTab('intake')}
          />
        )}

        {activeTab === 'checkin' && (
          <>
            {!canAccessStaff ? (
              <div className="rounded-xl border border-[#CBD8CE] bg-white p-8 max-w-xl mx-auto text-center space-y-4 shadow-sm">
                <Lock className="w-8 h-8 text-[#B91C1C] mx-auto" />
                <div className="font-mono text-xs uppercase tracking-widest text-[#B91C1C]">
                  HTTP 401 · STAFF AUTHENTICATION GUARD
                </div>
                <h2 className="font-display text-3xl font-semibold text-[#0F241D]">
                  Front Desk or Owner Login Required
                </h2>
                <p className="text-xs text-[#4E675E] leading-relaxed">
                  Under SRS Section 3.1 Role Access Matrix, the 10-digit phone
                  check-in console is restricted to authenticated Front Desk
                  Staff (`staff@ngyoga.in`) and Studio Owners
                  (`owner@ngyoga.in`).
                </p>
                <button
                  type="button"
                  onClick={() => setAuthModalOpen(true)}
                  className="px-5 py-3 rounded-lg bg-[#1B4332] text-white font-mono text-xs uppercase tracking-wider font-semibold cursor-pointer"
                >
                  Open Role Login Portal →
                </button>
              </div>
            ) : (
              <StaffCheckinView
                batches={snapshot.batches}
                checkins={snapshot.checkins}
                members={snapshot.members}
                onSnapshotUpdate={handleSnapshotUpdate}
              />
            )}
          </>
        )}

        {activeTab === 'owner' && (
          <>
            {!canAccessOwner ? (
              <div className="rounded-xl border border-[#CBD8CE] bg-white p-8 max-w-xl mx-auto text-center space-y-4 shadow-sm">
                <Lock className="w-8 h-8 text-[#B91C1C] mx-auto" />
                <div className="font-mono text-xs uppercase tracking-widest text-[#B91C1C]">
                  HTTP 403 · ELEVATED STUDIO OWNER GUARD
                </div>
                <h2 className="font-display text-3xl font-semibold text-[#0F241D]">
                  Studio Owner Role Required
                </h2>
                <p className="text-xs text-[#4E675E] leading-relaxed">
                  Your current session role is{' '}
                  <strong>{currentUser?.role || 'unauthenticated'}</strong>.
                  Sign in as <strong>Narayan Gothane (`owner@ngyoga.in`)</strong>{' '}
                  to access the Level 2 Retention Risk Registry and Conversion
                  Analytics.
                </p>
                <button
                  type="button"
                  onClick={() => setAuthModalOpen(true)}
                  className="px-5 py-3 rounded-lg bg-[#1B4332] text-white font-mono text-xs uppercase tracking-wider font-semibold cursor-pointer"
                >
                  Switch to Studio Owner Role →
                </button>
              </div>
            ) : (
              <OwnerRetentionDashboard
                retentionTriage={snapshot.retention_triage}
                conversionStats={snapshot.conversion_stats}
                onSnapshotUpdate={handleSnapshotUpdate}
              />
            )}
          </>
        )}
      </main>

      {/* Deep Forest Footer with 1-Click FastAPI + Next.js ZIP Download */}
      <footer className="border-t border-[#CBD8CE] bg-[#0F241D] text-[#F4F7F4] py-8 px-4 sm:px-8 mt-16">
        <div className="max-w-[1360px] mx-auto flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div>
            <div className="font-mono text-xs tracking-[0.18em] uppercase text-[#86EFAC]">
              NG YOGA STUDIO INDORE · CLINICAL SOMATIC &amp; WALL-ROPE SANCTUARY
            </div>
            <div className="text-xs text-[#E6EFE9]/80 mt-1">
              Prem Plaza, 5 &amp; 6, Samrat, Near ICICI Bank, Ashok Nagar,
              Indore (MP 452001) · Founder: Narayan Gothane (NG Gothane)
            </div>
            <div className="text-[11px] font-mono text-[#A3B8AF] mt-1.5">
              Mandatory Notice: This is not medical advice. Programme routing
              guides studio class suitability only.
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 font-mono text-xs">
            <button
              type="button"
              onClick={handleDownloadPlatformZip}
              className="px-4 py-2 rounded-lg bg-[#C86446] text-white hover:bg-[#b55538] font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <FolderArchive className="w-3.5 h-3.5" />
              <span>Download Full Platform ZIP (FastAPI + Next.js)</span>
            </button>
            <button
              type="button"
              onClick={() => setCmdOpen(true)}
              className="px-3 py-2 rounded-lg border border-white/20 text-[#E6EFE9] hover:bg-white/10 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Search (⌘K)</span>
            </button>
            <button
              type="button"
              onClick={handleExportJson}
              className="px-3 py-2 rounded-lg border border-white/20 text-[#E6EFE9] hover:bg-white/10 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>JSON</span>
            </button>
            <button
              type="button"
              onClick={handleExportRetentionCsv}
              className="px-3 py-2 rounded-lg border border-white/20 text-[#E6EFE9] hover:bg-white/10 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>CSV</span>
            </button>
            <button
              type="button"
              onClick={handleResetDemoData}
              disabled={resetting}
              className="px-3 py-2 rounded-lg border border-white/20 text-[#E6EFE9] hover:bg-white/10 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{resetting ? 'Resetting...' : 'Reset DB'}</span>
            </button>
          </div>
        </div>
      </footer>

      <AuthPortalModal
        isOpen={authModalOpen}
        currentUser={currentUser}
        onClose={() => setAuthModalOpen(false)}
        onLoginSuccess={(user, token) => {
          setCurrentUser(user);
          setJwtToken(token);
          if (user.phone) {
            syncActiveMemberFromSnapshot(snapshot, user.phone);
          }
        }}
        onLogout={() => {
          setCurrentUser(null);
          setJwtToken('');
        }}
      />

      {cmdOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-start justify-center pt-16 p-4">
          <div className="max-w-xl w-full rounded-xl border border-[#CBD8CE] bg-white shadow-xl overflow-hidden">
            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-[#CBD8CE] bg-[#E6EFE9]">
              <Search className="w-4 h-4 text-[#4E675E]" />
              <input
                type="text"
                autoFocus
                value={cmdQuery}
                onChange={(e) => setCmdQuery(e.target.value)}
                placeholder="Search practitioners by name or 10-digit phone..."
                className="w-full text-sm bg-transparent focus:outline-none font-mono text-[#0F241D]"
              />
              <button
                type="button"
                onClick={() => setCmdOpen(false)}
                className="p-1 text-[#4E675E] hover:text-[#0F241D] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <div>
                <div className="font-mono text-[10px] uppercase tracking-wider text-[#4E675E] mb-2">
                  SWITCH ACTIVE PRACTITIONER PROFILE ({filteredCmdMembers.length}
                  )
                </div>
                <div className="space-y-1.5">
                  {filteredCmdMembers.map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => {
                        syncActiveMemberFromSnapshot(snapshot, m.phone);
                        setCmdOpen(false);
                      }}
                      className="w-full text-left p-2.5 rounded-lg border border-[#CBD8CE] bg-[#F4F7F4] hover:bg-[#1B4332] hover:text-white transition-colors flex items-center justify-between text-xs cursor-pointer"
                    >
                      <div>
                        <span className="font-semibold">{m.name}</span>
                        <span className="font-mono ml-2 opacity-75">
                          +91 {m.phone} · {m.experience_level}
                        </span>
                      </div>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-[#CBD8CE] flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleDownloadPlatformZip}
                    className="px-3 py-1.5 rounded-lg bg-[#C86446] text-white font-mono text-xs uppercase cursor-pointer"
                  >
                    Download FastAPI + Next.js ZIP
                  </button>
                  <button
                    type="button"
                    onClick={handleExportJson}
                    className="px-3 py-1.5 rounded-lg border border-[#CBD8CE] bg-white font-mono text-xs uppercase hover:bg-[#E6EFE9] cursor-pointer"
                  >
                    Export JSON
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleResetDemoData}
                  className="px-3 py-1.5 rounded-lg bg-[#B91C1C] text-white font-mono text-xs uppercase cursor-pointer"
                >
                  Reset Seed Database
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
