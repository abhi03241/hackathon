'use client';

import React, {useState} from 'react';
import {
  Calendar,
  Clock,
  Users,
  Lock,
  CheckCircle2,
  AlertCircle,
  Trash2,
  ExternalLink,
  Info,
  Plus,
} from 'lucide-react';
import type {
  Batch,
  Booking,
  Member,
  Membership,
  ProgrammeType,
  RoutingResult,
  WaitlistEntry,
} from '@/types';
import {ALL_PROGRAMMES} from '@/lib/routing';

interface BatchesPlansViewProps {
  batches: Batch[];
  bookings: Booking[];
  waitlist: WaitlistEntry[];
  members: Member[];
  activeMember: Member | null;
  activeRouting: RoutingResult | null;
  activeMembership: Membership | null;
  hasUsedTrial: boolean;
  initialProgrammeFilter: ProgrammeType | 'ALL';
  onSelectActiveMemberByPhone: (phone: string) => void;
  onSnapshotUpdate: (snapshot: unknown) => void;
  onNavigateToIntake: () => void;
}

export default function BatchesPlansView({
  batches,
  bookings,
  waitlist,
  members,
  activeMember,
  activeRouting,
  activeMembership,
  hasUsedTrial,
  initialProgrammeFilter,
  onSelectActiveMemberByPhone,
  onSnapshotUpdate,
  onNavigateToIntake,
}: BatchesPlansViewProps) {
  const [slotFilter, setSlotFilter] = useState<'all' | 'morning' | 'evening'>(
    'all'
  );
  const [programmeFilter, setProgrammeFilter] = useState<
    ProgrammeType | 'ALL'
  >(initialProgrammeFilter);
  const [bookingType, setBookingType] = useState<'trial' | 'member'>(
    hasUsedTrial ? 'member' : 'trial'
  );
  const [applyLoyaltyCap, setApplyLoyaltyCap] = useState<boolean>(false);
  const [bannerAlert, setBannerAlert] = useState<{
    type: 'success' | 'error' | 'promoted';
    message: string;
    whatsappUrl?: string;
    promotedName?: string;
  } | null>(null);
  const [busyBatchId, setBusyBatchId] = useState<string | null>(null);
  const [busyPlan, setBusyPlan] = useState<string | null>(null);

  const filteredBatches = batches.filter((b) => {
    if (slotFilter !== 'all' && b.time_slot !== slotFilter) return false;
    if (programmeFilter !== 'ALL' && b.programme_type !== programmeFilter)
      return false;
    return true;
  });

  const handleBookBatch = async (batch: Batch) => {
    if (!activeMember) {
      setBannerAlert({
        type: 'error',
        message:
          'Please select or register a member in Health Intake before booking a batch.',
      });
      return;
    }

    setBusyBatchId(batch.id);
    setBannerAlert(null);

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          member_id: activeMember.id,
          batch_id: batch.id,
          booking_type: bookingType,
        }),
      });
      const data = await res.json();
      if (data.snapshot) {
        onSnapshotUpdate(data.snapshot);
      }

      if (!res.ok) {
        setBannerAlert({
          type: 'error',
          message: `HTTP ${res.status}: ${data.message}`,
        });
      } else {
        setBannerAlert({
          type: 'success',
          message: data.message,
        });
      }
    } catch {
      setBannerAlert({
        type: 'error',
        message: 'Network error while creating booking.',
      });
    } finally {
      setBusyBatchId(null);
    }
  };

  const handleJoinWaitlist = async (batch: Batch) => {
    if (!activeMember) {
      setBannerAlert({
        type: 'error',
        message:
          'Select or register a member profile first to join a batch waitlist.',
      });
      return;
    }

    setBusyBatchId(batch.id);
    setBannerAlert(null);

    try {
      const res = await fetch('/api/waitlist', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          member_id: activeMember.id,
          batch_id: batch.id,
        }),
      });
      const data = await res.json();
      if (data.snapshot) {
        onSnapshotUpdate(data.snapshot);
      }
      if (!res.ok) {
        setBannerAlert({
          type: 'error',
          message: data.message,
        });
      } else {
        setBannerAlert({
          type: 'success',
          message: data.message,
        });
      }
    } catch {
      setBannerAlert({
        type: 'error',
        message: 'Could not join waitlist.',
      });
    } finally {
      setBusyBatchId(null);
    }
  };

  const handleCancelBooking = async (bookingId: string) => {
    setBannerAlert(null);
    try {
      const res = await fetch(`/api/bookings/${bookingId}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (data.snapshot) {
        onSnapshotUpdate(data.snapshot);
      }
      if (data.promoted) {
        setBannerAlert({
          type: 'promoted',
          message: data.message,
          whatsappUrl: data.promoted.whatsapp_url,
          promotedName: data.promoted.promoted_member_name,
        });
      } else {
        setBannerAlert({
          type: 'success',
          message: data.message || 'Booking cancelled.',
        });
      }
    } catch {
      setBannerAlert({
        type: 'error',
        message: 'Failed to cancel booking.',
      });
    }
  };

  const handlePurchasePlan = async (
    planType: '1month' | '3months' | '6months'
  ) => {
    if (!activeMember) {
      setBannerAlert({
        type: 'error',
        message:
          'Please select or register a member first before activating a membership plan.',
      });
      return;
    }

    setBusyPlan(planType);
    setBannerAlert(null);

    try {
      const res = await fetch('/api/memberships', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          member_id: activeMember.id,
          plan_type: planType,
          apply_loyalty_cap: applyLoyaltyCap,
        }),
      });
      const data = await res.json();
      if (data.snapshot) {
        onSnapshotUpdate(data.snapshot);
      }
      if (res.ok) {
        setBookingType('member');
        setBannerAlert({
          type: 'success',
          message: data.message,
        });
      } else {
        setBannerAlert({
          type: 'error',
          message: data.message || 'Could not activate membership.',
        });
      }
    } catch {
      setBannerAlert({
        type: 'error',
        message: 'Network error activating plan.',
      });
    } finally {
      setBusyPlan(null);
    }
  };

  const today = new Date().toISOString().split('T')[0];

  const getMembershipStatusLabel = (ms: Membership | null) => {
    if (!ms) return {text: 'No Active Membership', tone: 'neutral'};
    if (ms.status === 'expired' || ms.expiry_date < today) {
      return {text: 'Expired', tone: 'danger'};
    }
    const daysLeft = Math.round(
      (new Date(ms.expiry_date + 'T00:00:00Z').getTime() -
        new Date(today + 'T00:00:00Z').getTime()) /
        (1000 * 60 * 60 * 24)
    );
    if (daysLeft <= 7) {
      return {text: `Expiring Soon (${daysLeft}d left)`, tone: 'warning'};
    }
    return {text: `Active (${daysLeft}d remaining)`, tone: 'success'};
  };

  const msStatus = getMembershipStatusLabel(activeMembership);

  return (
    <div className="space-y-10">
      {/* Header & Active Practitioner Context */}
      <section className="rounded-xl border border-[#CBD8CE] bg-white p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div>
            <div className="font-mono text-xs uppercase tracking-[0.16em] text-[#4E675E]">
              LEVEL 1 &amp; 3 · CAPACITY-LOCKED BATCHES (B1–B2), WAITLIST &amp;
              PLANS (B3)
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#0F241D] mt-1">
              Real-Time Cohort Schedule &amp; Membership Plans
            </h1>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center gap-3 rounded-lg bg-[#E6EFE9]/60 border border-[#CBD8CE] p-3.5">
            <div className="text-xs">
              <div className="font-mono text-[10px] uppercase tracking-wider text-[#4E675E]">
                BOOKING AS PRACTITIONER:
              </div>
              <select
                value={activeMember?.phone || ''}
                onChange={(e) => {
                  if (e.target.value === '__new__') {
                    onNavigateToIntake();
                  } else {
                    onSelectActiveMemberByPhone(e.target.value);
                  }
                }}
                className="mt-1 font-mono text-xs font-semibold bg-white rounded-md border border-[#CBD8CE] px-2.5 py-1.5 text-[#0F241D]"
              >
                <option value="" disabled>
                  -- Select Member or Complete Intake --
                </option>
                {members.map((m) => (
                  <option key={m.id} value={m.phone}>
                    {m.name} (+91 {m.phone}) · {m.experience_level}
                  </option>
                ))}
                <option value="__new__">+ New Member Health Intake...</option>
              </select>
            </div>

            {activeMember && (
              <div className="border-t sm:border-t-0 sm:border-l border-[#CBD8CE] pt-2 sm:pt-0 sm:pl-3 text-xs">
                <div className="font-mono text-[10px] uppercase text-[#4E675E]">
                  ROUTING &amp; TRIAL STATUS:
                </div>
                <div className="font-medium text-[#0F241D] mt-0.5">
                  Match: <strong>{activeRouting?.recommended || 'Any'}</strong>{' '}
                  · Trial: {hasUsedTrial ? 'Used (B2 Locked)' : 'Eligible (₹0)'}
                </div>
              </div>
            )}
          </div>
        </div>

        {bannerAlert && (
          <div
            className={`mt-5 p-4 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
              bannerAlert.type === 'error'
                ? 'border-[#B91C1C] bg-[#FEF2F2] text-[#B91C1C]'
                : bannerAlert.type === 'promoted'
                ? 'border-[#15803D] bg-[#F0FDF4] text-[#15803D]'
                : 'border-[#1B4332] bg-[#E6EFE9] text-[#0F241D]'
            }`}
          >
            <div className="flex items-start gap-2.5 text-xs font-medium">
              {bannerAlert.type === 'error' ? (
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              ) : (
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-[#15803D]" />
              )}
              <span>{bannerAlert.message}</span>
            </div>

            {bannerAlert.whatsappUrl && (
              <a
                href={bannerAlert.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#15803D] text-white font-mono text-xs uppercase tracking-wider font-semibold hover:bg-[#166534] transition-colors whitespace-nowrap shrink-0"
              >
                <span>Notify {bannerAlert.promotedName} on WhatsApp</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        )}
      </section>

      {/* Filter Bar */}
      <section className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#CBD8CE] pb-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center rounded-lg border border-[#CBD8CE] bg-white p-1">
            {(['all', 'morning', 'evening'] as const).map((slot) => (
              <button
                key={slot}
                type="button"
                onClick={() => setSlotFilter(slot)}
                className={`px-3 py-1.5 rounded-md font-mono text-xs uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap ${
                  slotFilter === slot
                    ? 'bg-[#1B4332] text-white font-semibold'
                    : 'text-[#0F241D] hover:bg-[#E6EFE9]'
                }`}
              >
                {slot === 'all'
                  ? 'All Slots'
                  : slot === 'morning'
                  ? 'Morning (6:30–10 AM)'
                  : 'Evening (5:00–9 PM)'}
              </button>
            ))}
          </div>

          <select
            value={programmeFilter}
            onChange={(e) =>
              setProgrammeFilter(e.target.value as ProgrammeType | 'ALL')
            }
            className="px-3 py-2 rounded-lg border border-[#CBD8CE] bg-white font-mono text-xs uppercase tracking-wider text-[#0F241D]"
          >
            <option value="ALL">All Programmes (7)</option>
            {ALL_PROGRAMMES.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-mono text-xs uppercase text-[#4E675E]">
            Booking Mode:
          </span>
          <div className="flex items-center rounded-lg border border-[#CBD8CE] bg-white p-1">
            <button
              type="button"
              onClick={() => setBookingType('trial')}
              className={`px-3 py-1.5 rounded-md font-mono text-xs uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap ${
                bookingType === 'trial'
                  ? 'bg-[#C86446] text-white font-semibold'
                  : 'text-[#0F241D]'
              }`}
            >
              1-Day Free Trial (Rule B2)
            </button>
            <button
              type="button"
              onClick={() => setBookingType('member')}
              className={`px-3 py-1.5 rounded-md font-mono text-xs uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap ${
                bookingType === 'member'
                  ? 'bg-[#1B4332] text-white font-semibold'
                  : 'text-[#0F241D]'
              }`}
            >
              Active Member Booking
            </button>
          </div>
        </div>
      </section>

      {/* Batch Cards Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredBatches.map((batch) => {
          const seatsRemaining = Math.max(
            0,
            batch.capacity - batch.booked_count
          );
          const isFull = seatsRemaining === 0;
          const isBlockedForMember =
            activeRouting?.hardBlock ||
            activeRouting?.blocked.includes(batch.programme_type) ||
            false;
          const blockReason = activeRouting?.hardBlock
            ? 'Rule R1: Please speak to an instructor before joining.'
            : activeRouting?.blockReasons[batch.programme_type];
          const isRecommended =
            activeRouting?.recommended === batch.programme_type &&
            !activeRouting?.hardBlock;

          const batchWaitlist = waitlist
            .filter((w) => w.batch_id === batch.id && !w.notified)
            .sort((a, b) => a.position - b.position);

          const batchConfirmedBookings = bookings.filter(
            (bk) => bk.batch_id === batch.id && bk.status === 'confirmed'
          );

          return (
            <div
              key={batch.id}
              className={`rounded-xl border p-5 flex flex-col justify-between transition-all ${
                isBlockedForMember
                  ? 'border-[#B91C1C]/40 bg-[#FEF2F2]/60'
                  : isRecommended
                  ? 'border-2 border-[#1B4332] bg-white shadow-md'
                  : 'border-[#CBD8CE] bg-white'
              }`}
            >
              <div>
                <div className="flex items-center justify-between text-xs font-mono text-[#4E675E]">
                  <span>
                    {batch.programme_type} ·{' '}
                    {batch.time_slot === 'morning' ? 'Morning' : 'Evening'}
                  </span>
                  <span
                    className={`font-semibold tabular-nums ${
                      isFull
                        ? 'text-[#B91C1C]'
                        : seatsRemaining <= 3
                        ? 'text-[#B45309]'
                        : 'text-[#15803D]'
                    }`}
                  >
                    {isFull
                      ? `FULL (${batch.booked_count}/${batch.capacity})`
                      : `${seatsRemaining} of ${batch.capacity} mats left`}
                  </span>
                </div>

                <h3 className="font-display text-2xl font-semibold text-[#0F241D] mt-1.5">
                  {batch.programme_name}
                </h3>

                <div className="mt-2.5 space-y-1 text-xs text-[#4E675E] font-mono tabular-nums">
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-[#1B4332]" />
                    <span>{batch.timing_label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-[#1B4332]" />
                    <span>Date: {batch.batch_date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-3.5 h-3.5 text-[#1B4332]" />
                    <span>Instructor: {batch.instructor}</span>
                  </div>
                </div>

                <div className="mt-4">
                  <div className="h-2 w-full rounded-full bg-[#E6EFE9] overflow-hidden">
                    <div
                      className={`h-full transition-all ${
                        isFull ? 'bg-[#B91C1C]' : 'bg-[#1B4332]'
                      }`}
                      style={{
                        width: `${Math.min(
                          100,
                          Math.round((batch.booked_count / batch.capacity) * 100)
                        )}%`,
                      }}
                    />
                  </div>
                </div>

                {isBlockedForMember && (
                  <div className="mt-3 p-2.5 rounded-lg border border-[#B91C1C]/40 bg-[#FEF2F2] text-[11px] text-[#B91C1C] flex items-start gap-2">
                    <Lock className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                    <span>{blockReason}</span>
                  </div>
                )}

                {(batchWaitlist.length > 0 ||
                  batchConfirmedBookings.length > 0) && (
                  <div className="mt-4 pt-3 border-t border-[#CBD8CE] space-y-2 text-[11px]">
                    {batchWaitlist.length > 0 && (
                      <div className="font-mono text-[#B45309]">
                        WAITLIST QUEUE ({batchWaitlist.length}):{' '}
                        {batchWaitlist
                          .map((w) => `#${w.position} ${w.member_name}`)
                          .join(' · ')}
                      </div>
                    )}

                    {batchConfirmedBookings.length > 0 && (
                      <div className="space-y-1">
                        <div className="font-mono text-[10px] uppercase text-[#4E675E]">
                          CONFIRMED ROSTER (CANCEL TO TRIGGER WAITLIST #1
                          PROMOTION):
                        </div>
                        {batchConfirmedBookings.slice(0, 2).map((bk) => (
                          <div
                            key={bk.id}
                            className="flex items-center justify-between rounded bg-[#F4F7F4] px-2.5 py-1.5 border border-[#CBD8CE]"
                          >
                            <span className="font-mono truncate text-[#0F241D]">
                              {bk.member_name} ({bk.booking_type})
                            </span>
                            <button
                              type="button"
                              onClick={() => handleCancelBooking(bk.id)}
                              className="text-[#B91C1C] hover:underline font-mono text-[10px] uppercase flex items-center gap-1 cursor-pointer ml-2 shrink-0"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Cancel</span>
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="mt-5 pt-3 border-t border-[#CBD8CE]">
                {isBlockedForMember ? (
                  <button
                    type="button"
                    disabled
                    className="w-full py-2.5 px-4 rounded-lg border border-[#B91C1C]/40 bg-[#FEF2F2] text-[#B91C1C] font-mono text-xs uppercase tracking-wider cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>Blocked by Safety Rule</span>
                  </button>
                ) : isFull ? (
                  <button
                    type="button"
                    disabled={busyBatchId === batch.id}
                    onClick={() => handleJoinWaitlist(batch)}
                    className="w-full py-2.5 px-4 rounded-lg bg-[#C86446] text-white hover:bg-[#b55538] font-mono text-xs uppercase tracking-wider font-semibold transition-colors cursor-pointer"
                  >
                    {busyBatchId === batch.id
                      ? 'Joining Waitlist...'
                      : `Batch Full — Join Waitlist (#${
                          batchWaitlist.length + 1
                        })`}
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={busyBatchId === batch.id}
                    onClick={() => handleBookBatch(batch)}
                    className="w-full py-2.5 px-4 rounded-lg bg-[#1B4332] text-white hover:bg-[#0F241D] font-mono text-xs uppercase tracking-wider font-semibold transition-colors cursor-pointer"
                  >
                    {busyBatchId === batch.id
                      ? 'Reserving Mat...'
                      : bookingType === 'trial'
                      ? 'Book 1-Day Free Trial (₹0)'
                      : 'Reserve Member Mat'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </section>

      {/* Membership Plans Section (Rule B3) */}
      <section
        id="membership-plans"
        className="rounded-xl border border-[#CBD8CE] bg-white p-6 sm:p-8 space-y-6 shadow-sm"
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#CBD8CE] pb-5">
          <div>
            <div className="font-mono text-xs uppercase tracking-[0.16em] text-[#4E675E]">
              RULE B3 · STUDIO MEMBERSHIP PLANS &amp; AUTOMATED EXPIRY
            </div>
            <h2 className="font-display text-3xl font-semibold text-[#0F241D] mt-1">
              Activate a Studio Membership Plan
            </h2>
            <p className="text-xs sm:text-sm text-[#4E675E] mt-1">
              Computed automatically as{' '}
              <span className="font-mono text-[#0F241D]">
                expiry_date = start_date + plan_duration_in_days
              </span>
              .
            </p>
          </div>

          {activeMember && (
            <div className="rounded-lg border border-[#CBD8CE] bg-[#F4F7F4] p-4 shrink-0">
              <div className="font-mono text-[10px] uppercase tracking-wider text-[#4E675E]">
                CURRENT PASS FOR {activeMember.name.toUpperCase()}:
              </div>
              <div className="mt-1 flex items-center gap-2">
                <span className="font-display text-xl font-semibold text-[#0F241D]">
                  {activeMembership
                    ? activeMembership.plan_label
                    : 'No Paid Plan'}
                </span>
                <span
                  className={`font-mono text-xs font-semibold ${
                    msStatus.tone === 'danger'
                      ? 'text-[#B91C1C]'
                      : msStatus.tone === 'warning'
                      ? 'text-[#B45309]'
                      : msStatus.tone === 'success'
                      ? 'text-[#15803D]'
                      : 'text-[#4E675E]'
                  }`}
                >
                  · {msStatus.text}
                </span>
              </div>
              {activeMembership && (
                <div className="font-mono text-[11px] text-[#4E675E] mt-1 tabular-nums">
                  Start: {activeMembership.start_date} · Expiry:{' '}
                  {activeMembership.expiry_date} · Paid: ₹
                  {activeMembership.price.toLocaleString('en-IN')}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between rounded-lg bg-[#E6EFE9]/60 border border-[#CBD8CE] px-4 py-3">
          <label className="flex items-center gap-2.5 text-xs font-medium cursor-pointer select-none text-[#0F241D]">
            <input
              type="checkbox"
              checked={applyLoyaltyCap}
              onChange={(e) => setApplyLoyaltyCap(e.target.checked)}
              className="w-4 h-4 accent-[#1B4332]"
            />
            <span>
              Apply <strong>Crisis Adaptation 10% Loyalty Renewal Lock</strong>{' '}
              (for pre-expiry &amp; returning members)
            </span>
          </label>
          <span className="font-mono text-[11px] text-[#4E675E]">
            Rule B3 Compliant
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {(
            [
              {
                planType: '1month' as const,
                title: '1 Month Practice Pass',
                audience: 'For foundational habit & posture alignment',
                durationDays: 30,
                price: 1500,
                cappedPrice: 1350,
                featured: false,
                features: [
                  '30 calendar days unlimited daily batch access',
                  'Shift-friendly between Morning & Evening slots',
                  'Initial spinal & blood-pressure posture screening',
                ],
              },
              {
                planType: '3months' as const,
                title: '3 Months Commitment',
                audience: 'Most chosen for Weight Loss & Spine Therapy',
                durationDays: 90,
                price: 4000,
                cappedPrice: 3600,
                featured: true,
                features: [
                  '90 calendar days access (Save ₹500 vs monthly)',
                  'Includes 15-min monthly 1-on-1 alignment review',
                  'Full access to wall-rope therapy & Sunday restorative',
                ],
              },
              {
                planType: '6months' as const,
                title: '6 Months Transformation',
                audience: 'For chronic PCOD, lumbar care & deep mobility',
                durationDays: 180,
                price: 7500,
                cappedPrice: 6750,
                featured: false,
                features: [
                  '180 calendar days access (Save ₹1,500 vs monthly)',
                  'Priority waitlist seating & personalized home pranayama',
                  'Dedicated progress tracking with NG Gothane',
                ],
              },
            ] as const
          ).map((plan) => {
            const displayPrice = applyLoyaltyCap
              ? plan.cappedPrice
              : plan.price;
            const computedExpiry = new Date(
              Date.now() + plan.durationDays * 24 * 60 * 60 * 1000
            )
              .toISOString()
              .split('T')[0];

            return (
              <div
                key={plan.planType}
                className={`rounded-xl border p-6 flex flex-col justify-between ${
                  plan.featured
                    ? 'border-2 border-[#1B4332] bg-[#F4F7F4] shadow-md'
                    : 'border-[#CBD8CE] bg-white'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between font-mono text-xs text-[#4E675E]">
                    <span>{plan.durationDays} DAYS DURATION</span>
                    {plan.featured && (
                      <span className="text-[#C86446] font-semibold">
                        ★ MOST CHOSEN
                      </span>
                    )}
                  </div>
                  <h3 className="font-display text-2xl font-semibold text-[#0F241D] mt-1">
                    {plan.title}
                  </h3>
                  <p className="text-xs text-[#4E675E] mt-1">{plan.audience}</p>

                  <div className="mt-4 pt-4 border-t border-[#CBD8CE] flex items-baseline gap-2 font-mono tabular-nums">
                    <span className="text-3xl font-bold text-[#0F241D]">
                      ₹{displayPrice.toLocaleString('en-IN')}
                    </span>
                    {applyLoyaltyCap && (
                      <span className="text-xs line-through text-[#4E675E]">
                        ₹{plan.price.toLocaleString('en-IN')}
                      </span>
                    )}
                  </div>

                  <div className="mt-2 font-mono text-[11px] text-[#15803D] tabular-nums">
                    Start: {today} → Expiry: {computedExpiry}
                  </div>

                  <ul className="mt-4 space-y-2 text-xs text-[#0F241D]/85">
                    {plan.features.map((f, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="font-mono text-[#1B4332]">•</span>
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  type="button"
                  disabled={busyPlan === plan.planType}
                  onClick={() => handlePurchasePlan(plan.planType)}
                  className="mt-6 w-full py-3 px-4 rounded-lg bg-[#1B4332] text-white hover:bg-[#0F241D] font-mono text-xs uppercase tracking-wider font-semibold transition-colors cursor-pointer"
                >
                  {busyPlan === plan.planType
                    ? 'Activating Pass...'
                    : `Activate ${plan.title} (₹${displayPrice.toLocaleString(
                        'en-IN'
                      )})`}
                </button>
              </div>
            );
          })}
        </div>

        <div className="pt-3 border-t border-[#CBD8CE] flex items-center gap-2 text-xs text-[#4E675E]">
          <Info className="w-4 h-4 shrink-0 text-[#1B4332]" />
          <span>
            <strong>Medical Disclaimer:</strong> This is not medical advice.
            Consult a qualified health professional for medical concerns.
          </span>
        </div>
      </section>
    </div>
  );
}
