# FastAPI package marker
