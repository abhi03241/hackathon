import StudioAppShell from '@/components/StudioAppShell';

export default function StaffCheckinPage() {
  return <StudioAppShell initialTab="checkin" />;
}
