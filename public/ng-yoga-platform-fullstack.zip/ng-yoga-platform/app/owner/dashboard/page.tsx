import StudioAppShell from '@/components/StudioAppShell';

export default function OwnerDashboardPage() {
  return <StudioAppShell initialTab="owner" />;
}
