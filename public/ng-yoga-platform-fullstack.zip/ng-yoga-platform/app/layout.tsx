import type {Metadata} from 'next';
import {Fraunces, Plus_Jakarta_Sans, IBM_Plex_Mono} from 'next/font/google';
import './globals.css';

const fraunces = Fraunces({
  subsets: ['latin'],
  weight: ['500', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-display',
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-sans',
});

const plexMono = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-mono',
});

export const metadata: Metadata = {
  title: 'NG Yoga Studio Indore — Clinical Somatic Routing & Membership Platform',
  description:
    'Clinical health-first programme routing, capacity-locked batch booking, front-desk check-in, and member retention triage for NG Yoga Studio, Ashok Nagar, Indore.',
  openGraph: {
    title: 'NG Yoga Studio Indore — Clinical Somatic Routing & Membership Platform',
    description:
      'Clinical health-first programme routing, capacity-locked batch booking, front-desk check-in, and member retention triage for NG Yoga Studio, Ashok Nagar, Indore.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'NG Yoga Studio Indore — Clinical Somatic Routing & Membership Platform',
    description:
      'Clinical health-first programme routing, capacity-locked batch booking, front-desk check-in, and member retention triage for NG Yoga Studio, Ashok Nagar, Indore.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html
      lang="en"
      className={`${fraunces.variable} ${jakarta.variable} ${plexMono.variable}`}
    >
      <body
        suppressHydrationWarning
        className="bg-[#F4F7F4] text-[#0F241D] font-sans antialiased selection:bg-[#1B4332] selection:text-[#F4F7F4] min-h-screen"
      >
        {children}
      </body>
    </html>
  );
}
