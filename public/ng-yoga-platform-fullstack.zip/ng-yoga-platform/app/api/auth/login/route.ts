import {NextRequest, NextResponse} from 'next/server';

const DEMO_USERS = [
  {
    id: 'usr-owner-ng',
    email: 'owner@ngyoga.in',
    password: 'owner123',
    name: 'Narayan Gothane (Founder & Studio Owner)',
    role: 'owner' as const,
    phone: '9171744543',
    tenant_id: 'tenant-indore-ashok-nagar',
  },
  {
    id: 'usr-staff-desk',
    email: 'staff@ngyoga.in',
    password: 'staff123',
    name: 'Ritu Sharma (Prem Plaza Front Desk)',
    role: 'staff' as const,
    phone: '7000656390',
    tenant_id: 'tenant-indore-ashok-nagar',
  },
  {
    id: 'usr-member-amit',
    email: 'amit@ngyoga.in',
    password: 'member123',
    name: 'Amit Patidar',
    role: 'member' as const,
    phone: '9826033333',
    tenant_id: 'tenant-indore-ashok-nagar',
  },
];

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const email = (body.email || '').trim().toLowerCase();
    const password = body.password || '';

    const found = DEMO_USERS.find(
      (u) => u.email === email && u.password === password
    );
    if (!found) {
      return NextResponse.json(
        {
          error: 'UNAUTHORIZED',
          message: 'Invalid email or password. Use one of the studio demo accounts.',
        },
        {status: 401}
      );
    }

    const tokenPayload = Buffer.from(
      JSON.stringify({
        sub: found.id,
        email: found.email,
        name: found.name,
        role: found.role,
        phone: found.phone,
        tenant_id: found.tenant_id,
        iat: Date.now(),
      })
    ).toString('base64');

    return NextResponse.json({
      access_token: `ngyoga_jwt_${tokenPayload}`,
      token_type: 'bearer',
      user: {
        id: found.id,
        email: found.email,
        name: found.name,
        role: found.role,
        phone: found.phone,
        tenant_id: found.tenant_id,
      },
    });
  } catch {
    return NextResponse.json(
      {error: 'BAD_REQUEST', message: 'Invalid login payload.'},
      {status: 400}
    );
  }
}
